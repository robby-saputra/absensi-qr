<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Http\Controllers\Web\AuthWebController;
use App\Http\Controllers\Api\AbsensiController;
use App\Models\User;
use App\Models\QrCode;


/*
|--------------------------------------------------------------------------
| HOME
|--------------------------------------------------------------------------
*/
Route::get('/', function () {
    return redirect('/login');
});

/*
|--------------------------------------------------------------------------
| LOGIN WEB
|--------------------------------------------------------------------------
*/
Route::get('/login', [AuthWebController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthWebController::class, 'login']);
Route::get('/logout', [AuthWebController::class, 'logout']);

/*
|--------------------------------------------------------------------------
| DASHBOARD ADMIN
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin', function () {

    $user = session('user');

    $totalSiswa = User::where('role', 'siswa')->count();
    $totalGuru = User::whereIn('role', ['guru', 'wali_kelas'])->count();
    $totalKelas = DB::table('kelas')->count();

    return view('dashboard.admin', compact(
        'user',
        'totalSiswa',
        'totalGuru',
        'totalKelas'
    ));

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| LIST GURU
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/guru', function () {

    $user = session('user');

    $guru = User::whereIn('role', ['guru', 'wali_kelas'])
        ->latest('id')
        ->get();

    return view('dashboard.guru.index', compact('user', 'guru'));

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| FORM TAMBAH GURU
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/guru/create', function () {

    $user = session('user');

    return view('dashboard.guru.create', compact('user'));

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| SIMPAN GURU
|--------------------------------------------------------------------------
*/
Route::post('/dashboard/admin/guru/store', function (Request $request) {

    $request->validate([
        'nama' => 'required',
        'nuptk' => 'nullable',
        'username' => 'required|unique:users,username',
        'password' => 'required',
        'role' => 'required|in:guru,wali_kelas'
    ]);

    User::create([
        'nama' => $request->nama,
        'nuptk' => $request->nuptk,
        'username' => $request->username,
        'password' => $request->password,
        'role' => $request->role,
        'kelas' => null,
        'no_ortu' => null,
    ]);

    return redirect('/dashboard/admin/guru');

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| HAPUS GURU
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/guru/delete/{id}', function ($id) {

    User::where('id', $id)
        ->whereIn('role', ['guru', 'wali_kelas'])
        ->delete();

    return redirect('/dashboard/admin/guru');

})->middleware('webrole:admin');
/*
|--------------------------------------------------------------------------
| LIST KELAS
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/kelas', function () {

    $user = session('user');

    $kelas = DB::table('kelas')
        ->latest('id')
        ->get();

    return view('dashboard.kelas.index', compact('user', 'kelas'));

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| FORM TAMBAH KELAS
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/kelas/create', function () {

    $user = session('user');

    return view('dashboard.kelas.create', compact('user'));

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| SIMPAN KELAS
|--------------------------------------------------------------------------
*/
Route::post('/dashboard/admin/kelas/store', function (Request $request) {

    $request->validate([
        'nama_kelas' => 'required|unique:kelas,nama_kelas'
    ]);

    DB::table('kelas')->insert([
        'nama_kelas' => $request->nama_kelas,
        'created_at' => now(),
        'updated_at' => now(),
    ]);

    return redirect('/dashboard/admin/kelas');

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| HAPUS KELAS
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/kelas/delete/{id}', function ($id) {

    DB::table('kelas')
        ->where('id', $id)
        ->delete();

    return redirect('/dashboard/admin/kelas');

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| LIST JADWAL
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/jadwal', function () {

    $user = session('user');

    $jadwal = DB::table('jadwal_pelajarans as j')
        ->join('kelas as k', 'k.id', '=', 'j.kelas_id')
        ->join('mapels as m', 'm.id', '=', 'j.mapel_id')
        ->join('users as g', 'g.id', '=', 'j.guru_id')
        ->select(
            'j.*',
            'k.nama_kelas',
            'm.nama_mapel',
            'g.nama as nama_guru'
        )
        ->orderBy('j.hari')
        ->orderBy('j.jam_mulai')
        ->get();

    return view('dashboard.jadwal.index', compact('user', 'jadwal'));

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| FORM TAMBAH JADWAL
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/jadwal/create', function () {

    $user = session('user');

    $kelas = DB::table('kelas')->orderBy('nama_kelas')->get();

    $mapels = DB::table('mapels')->orderBy('nama_mapel')->get();

    $guru = User::whereIn('role', ['guru', 'wali_kelas'])
        ->orderBy('nama')
        ->get();

    return view('dashboard.jadwal.create', compact(
        'user',
        'kelas',
        'mapels',
        'guru'
    ));

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| SIMPAN JADWAL
|--------------------------------------------------------------------------
*/
Route::post('/dashboard/admin/jadwal/store', function (Request $request) {

    $request->validate([
        'kelas_id' => 'required',
        'hari' => 'required',
        'jam_mulai' => 'required',
        'jam_selesai' => 'required',
        'mapel_id' => 'required',
        'guru_id' => 'required',
    ]);

    DB::table('jadwal_pelajarans')->insert([
        'kelas_id' => $request->kelas_id,
        'hari' => $request->hari,
        'jam_mulai' => $request->jam_mulai,
        'jam_selesai' => $request->jam_selesai,
        'mapel_id' => $request->mapel_id,
        'guru_id' => $request->guru_id,
        'created_at' => now(),
        'updated_at' => now(),
    ]);

    return redirect('/dashboard/admin/jadwal');

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| HAPUS JADWAL
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/jadwal/delete/{id}', function ($id) {

    DB::table('jadwal_pelajarans')
        ->where('id', $id)
        ->delete();

    return redirect('/dashboard/admin/jadwal');

})->middleware('webrole:admin');


/*
|--------------------------------------------------------------------------
| MONITORING NILAI
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/nilai', function () {

    $user = session('user');

    $nilai = DB::table('nilais as n')
        ->join('users as s', 's.id', '=', 'n.siswa_id')
        ->join('users as g', 'g.id', '=', 'n.guru_id')
        ->join('mapels as m', 'm.id', '=', 'n.mapel_id')
        ->select(
            'n.*',
            's.nama as nama_siswa',
            's.kelas',
            'g.nama as nama_guru',
            'm.nama_mapel'
        )
        ->latest('n.id')
        ->get();

    return view('dashboard.nilai.index', compact(
        'user',
        'nilai'
    ));

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| FORM EDIT NILAI
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/nilai/edit/{id}', function ($id) {

    $user = session('user');

    $nilai = DB::table('nilais')->where('id', $id)->first();

    if (!$nilai) {
        abort(404);
    }

    return view('dashboard.nilai.edit', compact(
        'user',
        'nilai'
    ));

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| UPDATE NILAI
|--------------------------------------------------------------------------
*/
Route::post('/dashboard/admin/nilai/update/{id}', function (Request $request, $id) {

    $request->validate([
        'nilai' => 'required|numeric|min:0|max:100'
    ]);

    DB::table('nilais')
        ->where('id', $id)
        ->update([
            'nilai' => $request->nilai,
            'updated_at' => now(),
        ]);

    return redirect('/dashboard/admin/nilai');

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| HAPUS NILAI
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/nilai/delete/{id}', function ($id) {

    DB::table('nilais')
        ->where('id', $id)
        ->delete();

    return redirect('/dashboard/admin/nilai');

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| LIST SISWA
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/siswa', function () {

    $user = session('user');

    $siswa = User::where('role', 'siswa')
        ->latest('id')
        ->get();

    return view('dashboard.siswa.index', compact(
        'user',
        'siswa'
    ));

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| FORM TAMBAH SISWA
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/siswa/create', function () {

    $user = session('user');

$wali = User::where('role', 'wali_kelas')
    ->orderBy('nama')
    ->get();

return view('dashboard.siswa.create', compact(
    'user',
    'wali'
));
})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| SIMPAN SISWA
|--------------------------------------------------------------------------
*/
Route::post('/dashboard/admin/siswa/store', function (Request $request) {

    $request->validate([
        'nama' => 'required',
        'username' => 'required|unique:users,username',
        'password' => 'required',
        'kelas' => 'required',
    ]);

    User::create([
    'nama' => $request->nama,
    'nuptk' => null,
    'username' => $request->username,
    'password' => $request->password,
    'role' => 'siswa',
    'kelas' => $request->kelas,
    'wali_kelas_id' => $request->wali_kelas_id,
    'no_ortu' => $request->no_ortu,
]);
    return redirect('/dashboard/admin/siswa');

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| HAPUS SISWA
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/siswa/delete/{id}', function ($id) {

    User::where('id', $id)
        ->where('role', 'siswa')
        ->delete();

    return redirect('/dashboard/admin/siswa');

})->middleware('webrole:admin');
/*
|--------------------------------------------------------------------------
| LIST WALI KELAS
|--------------------------------------------------------------------------
*/
/*
|--------------------------------------------------------------------------
| LIST WALI KELAS
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/wali-kelas', function () {

    $user = session('user');

    $wali = DB::table('wali_kelas as w')
        ->join('users as g', 'g.id', '=', 'w.guru_id')
        ->join('kelas as k', 'k.id', '=', 'w.kelas_id')
        ->select(
            'w.id',
            'g.nama',
            'g.username',
            'k.nama_kelas'
        )
        ->latest('w.id')
        ->get();

    return view('dashboard.wali_kelas.index', compact(
        'user',
        'wali'
    ));

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| FORM TAMBAH WALI KELAS
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/wali-kelas/create', function () {

    $user = session('user');

    $guru = User::where('role', 'guru')
        ->orderBy('nama')
        ->get();

    $kelas = DB::table('kelas')
        ->orderBy('nama_kelas')
        ->get();

    return view('dashboard.wali_kelas.create', compact(
        'user',
        'guru',
        'kelas'
    ));

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| SIMPAN WALI KELAS
|--------------------------------------------------------------------------
*/
Route::post('/dashboard/admin/wali-kelas/store', function (Request $request) {

    $request->validate([
        'guru_id' => 'required',
        'kelas_id' => 'required',
    ]);

    DB::table('wali_kelas')->insert([
        'guru_id' => $request->guru_id,
        'kelas_id' => $request->kelas_id,
        'created_at' => now(),
        'updated_at' => now(),
    ]);

    return redirect('/dashboard/admin/wali-kelas');

})->middleware('webrole:admin');

/*
|--------------------------------------------------------------------------
| HAPUS WALI KELAS
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/admin/wali-kelas/delete/{id}', function ($id) {

   DB::table('wali_kelas')
    ->where('id', $id)
    ->delete();

return redirect('/dashboard/admin/wali-kelas');

})->middleware('webrole:admin');
/*
|--------------------------------------------------------------------------
| DASHBOARD PIKET
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/piket', function (Request $request) {

    $user = session('user');

    $tipe = $request->get('tipe', 'masuk');

    $qr = QrCode::whereDate('tanggal', now()->toDateString())
        ->where('tipe', $tipe)
        ->latest('id')
        ->first();

    return view('dashboard.piket', compact('user', 'qr', 'tipe'));

})->middleware('webrole:piket');

/*
|--------------------------------------------------------------------------
| GENERATE QR
|--------------------------------------------------------------------------
*/
Route::post('/dashboard/piket/generate-qr', function (Request $request) {

    $request->validate([
        'tipe' => 'required|in:masuk,pulang'
    ]);

    QrCode::create([
        'tanggal' => now()->toDateString(),
        'tipe' => $request->tipe,
        'token' => Str::random(12),
    ]);

    return redirect('/dashboard/piket?tipe=' . $request->tipe);

})->middleware('webrole:piket');

/*
|--------------------------------------------------------------------------
| DASHBOARD WALI KELAS
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/wali', function () {

    $user = session('user');

    // cek apakah guru ini wali kelas
    $wali = DB::table('wali_kelas as w')
        ->join('kelas as k', 'k.id', '=', 'w.kelas_id')
        ->select(
            'w.*',
            'k.nama_kelas'
        )
        ->where('w.guru_id', $user->id)
        ->first();

    // kalau bukan wali kelas
    if (!$wali) {
        abort(403, 'Akses ditolak');
    }

    $siswa = User::where('role', 'siswa')
    ->where('kelas', $wali->nama_kelas)
    ->orderBy('nama')
    ->get();

foreach ($siswa as $s) {

    $absen = DB::table('absensis')
        ->where('id_siswa', $s->id)
        ->whereDate('tanggal', now()->toDateString())
        ->first();

    if ($absen) {

        $s->status_hari_ini = $absen->status_masuk;

    } else {

        $s->status_hari_ini = 'belum_absen';
    }
}

    return view('dashboard.wali', compact(
        'user',
        'siswa',
        'wali'
    ));

})->middleware('webrole:guru');
/*
|--------------------------------------------------------------------------
| DATA SISWA WALI KELAS
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/wali/siswa', function () {

    $user = session('user');

    $wali = DB::table('wali_kelas as w')
        ->join('kelas as k', 'k.id', '=', 'w.kelas_id')
        ->select('k.nama_kelas')
        ->where('w.guru_id', $user->id)
        ->first();

    if (!$wali) {
        abort(403);
    }

    $siswa = User::where('role', 'siswa')
        ->where('kelas', $wali->nama_kelas)
        ->orderBy('nama')
        ->get();

    return view('dashboard.wali_siswa', compact(
        'user',
        'wali',
        'siswa'
    ));

})->middleware('webrole:guru');

/*
|--------------------------------------------------------------------------
| MONITORING NILAI WALI KELAS
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/wali/nilai', function () {

    $user = session('user');

    $wali = DB::table('wali_kelas as w')
        ->join('kelas as k', 'k.id', '=', 'w.kelas_id')
        ->select('k.nama_kelas')
        ->where('w.guru_id', $user->id)
        ->first();

    if (!$wali) {
        abort(403);
    }

    $nilai = DB::table('nilais as n')
        ->join('users as s', 's.id', '=', 'n.siswa_id')
        ->join('mapels as m', 'm.id', '=', 'n.mapel_id')
        ->select(
            'n.*',
            's.nama as nama_siswa',
            's.kelas',
            'm.nama_mapel'
        )
        ->where('s.kelas', $wali->nama_kelas)
        ->latest('n.id')
        ->get();

    return view('dashboard.wali_nilai', compact(
        'user',
        'wali',
        'nilai'
    ));

})->middleware('webrole:guru');

/*
|--------------------------------------------------------------------------
| ABSENSI SISWA WALI KELAS
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/wali/absensi', function () {

    $user = session('user');

    $wali = DB::table('wali_kelas as w')
        ->join('kelas as k', 'k.id', '=', 'w.kelas_id')
        ->select('k.nama_kelas')
        ->where('w.guru_id', $user->id)
        ->first();

    if (!$wali) {
        abort(403);
    }

    $absensi = DB::table('absensis as a')
        ->join('users as s', 's.id', '=', 'a.id_siswa')
        ->select(
            'a.*',
            's.nama',
            's.kelas'
        )
        ->where('s.kelas', $wali->nama_kelas)
        ->whereDate('a.tanggal', now()->toDateString())
        ->latest('a.id')
        ->get();

    return view('dashboard.wali_absensi', compact(
        'user',
        'wali',
        'absensi'
    ));

})->middleware('webrole:guru');
/*
|--------------------------------------------------------------------------
| DASHBOARD GURU MAPEL
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/guru', function () {

    $user = session('user');

    $hari = now()->locale('id')->isoFormat('dddd');

    $jadwal = DB::table('jadwal_pelajarans as j')
        ->join('kelas as k', 'k.id', '=', 'j.kelas_id')
        ->join('mapels as m', 'm.id', '=', 'j.mapel_id')
        ->where('j.guru_id', $user->id)
        ->where('j.hari', $hari)
        ->select(
            'j.*',
            'k.nama_kelas',
            'm.nama_mapel'
        )
        ->orderBy('j.jam_mulai')
        ->get();

    $isWaliKelas = DB::table('wali_kelas')
    ->where('guru_id', $user->id)
    ->exists();

return view('dashboard.guru', compact(
    'user',
    'jadwal',
    'hari',
    'isWaliKelas'
));

})->middleware('webrole:guru');

/*
|--------------------------------------------------------------------------
| MULAI SESI GURU (GENERATE QR)
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/guru/mulai-sesi/{jadwalId}', function ($jadwalId) {

    $user = session('user');

    $jadwal = DB::table('jadwal_pelajarans')
        ->where('id', $jadwalId)
        ->where('guru_id', $user->id)
        ->first();

    if (!$jadwal) {
        abort(403);
    }

    $qr = DB::table('qr_sesis')
        ->where('jadwal_id', $jadwalId)
        ->whereDate('tanggal', now()->toDateString())
        ->where('aktif', 1)
        ->first();

    if (!$qr) {
        $token = Str::random(20);

        DB::table('qr_sesis')->insert([
            'jadwal_id' => $jadwalId,
            'tanggal' => now()->toDateString(),
            'token' => $token,
            'aktif' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $qr = DB::table('qr_sesis')
            ->where('jadwal_id', $jadwalId)
            ->whereDate('tanggal', now()->toDateString())
            ->first();
    }

    $detail = DB::table('jadwal_pelajarans as j')
        ->join('kelas as k', 'k.id', '=', 'j.kelas_id')
        ->join('mapels as m', 'm.id', '=', 'j.mapel_id')
        ->select(
            'j.*',
            'k.nama_kelas',
            'm.nama_mapel'
        )
        ->where('j.id', $jadwalId)
        ->first();

    return view('dashboard.guru_qr', compact(
        'user',
        'qr',
        'detail'
    ));

})->middleware('webrole:guru');

/*
|--------------------------------------------------------------------------
| FORM INPUT NILAI GURU
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/guru/nilai/{jadwalId}', function ($jadwalId) {

    $user = session('user');

    $jadwal = DB::table('jadwal_pelajarans as j')
        ->join('kelas as k', 'k.id', '=', 'j.kelas_id')
        ->join('mapels as m', 'm.id', '=', 'j.mapel_id')
        ->select(
            'j.*',
            'k.nama_kelas',
            'm.nama_mapel'
        )
        ->where('j.id', $jadwalId)
        ->where('j.guru_id', $user->id)
        ->first();

    if (!$jadwal) {
        abort(403);
    }

    $siswa = User::where('role', 'siswa')
        ->where('kelas', $jadwal->nama_kelas)
        ->orderBy('nama')
        ->get();

    return view('dashboard.guru_nilai', compact(
        'user',
        'jadwal',
        'siswa'
    ));

})->middleware('webrole:guru');

/*
|--------------------------------------------------------------------------
| SIMPAN NILAI GURU
|--------------------------------------------------------------------------
*/
Route::post('/dashboard/guru/nilai/store', function (Request $request) {

    $request->validate([
        'siswa_id' => 'required',
        'mapel_id' => 'required',
        'guru_id' => 'required',
        'jenis_nilai' => 'required',
       'nilai' => 'nullable|numeric|min:0|max:100',
'keterangan' => 'nullable',
    ]);

    DB::table('nilais')->insert([
        'siswa_id' => $request->siswa_id,
        'mapel_id' => $request->mapel_id,
        'guru_id' => $request->guru_id,
        'jenis_nilai' => $request->jenis_nilai,
       'nilai' => $request->nilai,
'keterangan' => $request->keterangan,
        'semester' => 'Genap',
        'tahun_ajaran' => '2025/2026',
        'created_at' => now(),
        'updated_at' => now(),
    ]);

    return back()->with('success', 'Nilai berhasil disimpan');

})->middleware('webrole:guru');

/*
|--------------------------------------------------------------------------
| NILAI HARI INI
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/guru/nilai-hari-ini/{jadwalId}', function ($jadwalId) {

    $user = session('user');

    $nilai = DB::table('nilais as n')
        ->join('users as s', 's.id', '=', 'n.siswa_id')
        ->join('mapels as m', 'm.id', '=', 'n.mapel_id')
        ->join('jadwal_pelajarans as j', 'j.mapel_id', '=', 'm.id')
        ->select(
            'n.*',
            's.nama as nama_siswa',
            's.kelas',
            'm.nama_mapel'
        )
        ->where('n.guru_id', $user->id)
        ->where('j.id', $jadwalId)
        ->whereDate('n.created_at', now()->toDateString())
        ->latest('n.id')
        ->get();

    return view('dashboard.guru_nilai_hari_ini', compact(
        'user',
        'nilai'
    ));

})->middleware('webrole:guru');

/*
|--------------------------------------------------------------------------
| SEMUA NILAI
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/guru/semua-nilai/{jadwalId}', function ($jadwalId) {

    $user = session('user');

    $nilai = DB::table('nilais as n')
        ->join('users as s', 's.id', '=', 'n.siswa_id')
        ->join('mapels as m', 'm.id', '=', 'n.mapel_id')
        ->join('jadwal_pelajarans as j', 'j.mapel_id', '=', 'm.id')
        ->select(
            'n.*',
            's.nama as nama_siswa',
            's.kelas',
            'm.nama_mapel'
        )
        ->where('n.guru_id', $user->id)
        ->where('j.id', $jadwalId)
        ->latest('n.id')
        ->get();

    return view('dashboard.guru_semua_nilai', compact(
        'user',
        'nilai'
    ));

})->middleware('webrole:guru');

/*
|--------------------------------------------------------------------------
| DASHBOARD USERS (SISWA)
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/users', function () {

    $user = session('user');

    $siswa = User::where('role', 'siswa')->get();

    return view('dashboard.users', compact('user', 'siswa'));

})->middleware('webrole:siswa');

/*
|--------------------------------------------------------------------------
| DASHBOARD USERS (SISWA)
|--------------------------------------------------------------------------
*/
Route::get('/dashboard/users', function () {

    $user = session('user');

    $siswa = User::where('role', 'siswa')->get();

    return view('dashboard.users', compact('user', 'siswa'));

})->middleware('webrole:siswa');

/*
|--------------------------------------------------------------------------
| WEB MANUAL ABSENSI (TESTING ONLY)
|--------------------------------------------------------------------------
*/
Route::post('/absensi/manual', function (Request $request) {

    $user = session('user');

    if (!$user) {
        return back()->with('error', 'User tidak login');
    }

    $qr = QrCode::where('token', $request->token)->first();

    if (!$qr) {
        return back()->with('error', 'QR tidak valid');
    }

    $request->attributes->set('user_login_id', $user->id);

    return app(AbsensiController::class)->scan($request);

});